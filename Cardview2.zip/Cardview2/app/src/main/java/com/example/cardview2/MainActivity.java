package com.example.cardview2;

import androidx.appcompat.app.AppCompatActivity;
import androidx.cardview.widget.CardView;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;

public class MainActivity extends AppCompatActivity {

    private CardView c1,c2,c3,c4;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        c1 = (CardView) findViewById(R.id.cv1);
        // Capture button clicks
        c1.setOnClickListener(new View.OnClickListener() {
            public void onClick(View arg0) {
                // Start NewActivity.class
                Intent myIntent1 = new Intent(MainActivity.this,
                        Message.class);
                startActivity(myIntent1);
            }
        });
        c2 = (CardView) findViewById(R.id.cv2);
        // Capture button clicks
        c2.setOnClickListener(new View.OnClickListener() {
            public void onClick(View arg0) {
                // Start NewActivity.class
                Intent myIntent1 = new Intent(MainActivity.this,
                        Location.class);
                startActivity(myIntent1);
            }
        });
        c3 = (CardView) findViewById(R.id.cv3);
        // Capture button clicks
        c3.setOnClickListener(new View.OnClickListener() {
            public void onClick(View arg0) {
                // Start NewActivity.class
                Intent myIntent1 = new Intent(MainActivity.this,
                        Wish.class);
                startActivity(myIntent1);
            }
        });
        c4 = (CardView) findViewById(R.id.cv4);
        // Capture button clicks
        c4.setOnClickListener(new View.OnClickListener() {
            public void onClick(View arg0) {
                // Start NewActivity.class
                Intent myIntent1 = new Intent(MainActivity.this,
                        Study.class);
                startActivity(myIntent1);
            }
        });
    }
}
